/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package util;

/**
 *
 * @author yeli4
 */
public class ModelConstants {
    public static final int MOVE_DISTANCE=20;
    public static final double HOST_CREATION_PROBABILITY=0.2;
    public static final double ARTIST_CREATION_PROBABILITY=0.2;
    public static final double SCIENTIST_CREATION_PROBABILITY=0.2;
    public static final double ENGINEER_CREATION_PROBABILITY=0.2;
    public static final int WIDTH=50;
    public static final int DEPTH=50;
    public static final int SEED=44;
    public static final int SIMULATION_LENGTH=1000;
    
//    public final void setMOVE_DISTANCE(int x){
//        this.MOVE_DISTANCE=x;
//    }
//    
//    public final void setHOST_CREATION_PROBABILITY(double x){
//        this.HOST_CREATION_PROBABILITY=x;
//    }
//
//    public final void setARTIST_CREATION_PROBABILITY(double x){
//        this.ARTIST_CREATION_PROBABILITY=x;
//    }
//
//    public final void setSCIENTIST_CREATION_PROBABILITY(double x){
//        this.SCIENTIST_CREATION_PROBABILITY=x;
//    }
//
//    public final void setENGINEER_CREATION_PROBABILITY(double x){
//        this.ENGINEER_CREATION_PROBABILITY=x;
//    }
//    
//    public final void setWIDTH(int x){
//        this.WIDTH=x;
//    }
//
//    public final void setDEPTH(int x){
//        this.DEPTH=x;
//    }
//
//    public final void setSEED(int x){
//        this.SEED=x;
//    }
//
//    public final void setSIMULATION_LENGTH(int x){
//        this.SIMULATION_LENGTH=x;
//    }

}
