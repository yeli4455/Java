package model;

import java.util.Random;
import util.ModelConstants;

class RandomGenerator {
	private static Random random=null;
	private static int seed=ModelConstants.SEED;

	public static void initialiseWithSeed(int s)
	{
		seed = s;
		random = new Random(seed);
	}
	
	public static Random getRandom()
	{
		if(random==null){
			random = new Random(seed);
		}
		return random;
	}	
}
