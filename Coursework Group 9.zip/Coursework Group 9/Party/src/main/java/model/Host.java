/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
import java.util.Iterator;
/**
 *
 * @author yeli4
 */
public class Host extends Person{ 
    public Host(int x, int y){
        super(x,y);
        this.name="host";
    }
    
    public Field act(Field field){
        Location location = new Location(this.row, this.col);
        Iterator<Location> locations = field.adjacentLocations(location);
        if (field.freeAdjacentLocation(location)!=null){
            boolean foundEmpty=false;
            while(foundEmpty==false && locations.hasNext()){
                Location location1 = locations.next();
                if(field.getObjectAt(location1)==null){
                    foundEmpty=true; 
                    Person person = field.getObjectAt(location);
                    field.place(person, location1);
                    field.clearLocation(location);
                    this.row=location1.getRow();
                    this.col=location1.getCol();
                    
                }
            }
                     
        }
        return field;
    }

}
