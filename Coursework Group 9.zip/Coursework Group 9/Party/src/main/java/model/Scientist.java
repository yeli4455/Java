/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
/**
 *
 * @author yeli4
 */
public final class Scientist extends Guest implements PreferArtist, PreferScientist{
    public Scientist(int row, int col){
        super(row,col);
        this.name="scientist";
        preferArtist();
        preferScientist();
    }
    
    @Override
     public void preferArtist(){
        this.preference.add("artist");
    }
    
    @Override
    public void preferScientist(){
        this.preference.add("scientist");
    }

}
