/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
import java.util.ArrayList;
import java.util.Iterator;
import util.ModelConstants;
/**
 *
 * @author yeli4
 */
public class Guest extends Person{
    protected int happinessLevel=0;
    protected ArrayList<String> preference = new ArrayList<String>();
   
    public Guest(int x, int y){
        super(x,y);
        this.preference.add("host");
    }
    
    /**
     *
     * @param field
     * @return
     */
    @Override
    public Field act(Field field){
        Location location = new Location(this.row,this.col);
        Iterator<Location> locations = field.adjacentLocations(location, ModelConstants.MOVE_DISTANCE);
        ArrayList<Integer> happinessLevels = new ArrayList<>();
        ArrayList<Location> loc = new ArrayList<Location>();
        while (locations.hasNext()){
            Location location1 = locations.next();
            if (field.getObjectAt(location1)==null){
                loc.add(location1);
                setHappinessLevel(field,location1.getRow(),location1.getCol());
                Integer h = new Integer(getHappinessLevel());
                happinessLevels.add(h);
            }
            
            
        }
        int highest = findHighest(happinessLevels);
        if (highest<loc.size()){
            Location loc1 = loc.get(highest);
            field.place(field.getObjectAt(location), loc1);
            field.clearLocation(location);
            this.row=loc1.getRow();
            this.col=loc1.getCol();
        }
        return field;
       
    }
    private int findHighest(ArrayList<Integer> h){
    int highest=0;
    for (int i=1; i<h.size(); i++){
        if(h.get(highest)<h.get(i)){
            highest=i;
        }
    }
    return highest;
}
    public void setHappinessLevel(Field field, int row, int col){
        this.happinessLevel=0;
        Location thisLocation = new Location(row,col);
        Iterator<Location> locations= field.adjacentLocations(thisLocation); 
        while(locations.hasNext()){
            Location location=locations.next(); 
            if(field.getObjectAt(location)!=null){
                String check = field.getObjectAt(location).getName();
                for(int i=0; i<preference.size(); i++){
                    if(check == this.preference.get(i)){
                        this.happinessLevel++;
                    }
                }
            }
        }


    }
    public int getHappinessLevel(){
        return this.happinessLevel;
    }   

}
