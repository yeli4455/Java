/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
/**
 *
 * @author yeli4
 */
public final class Engineer extends Guest implements PreferArtist, PreferScientist, PreferEngineer{
    public Engineer(int row, int col){
        super(row,col);
        this.name="engineer";
        preferArtist();
        preferScientist();
        preferEngineer();
    }
    
    @Override
    public void preferArtist(){
        preference.add("artist");
    }
    
    @Override
    public void preferScientist(){
        preference.add("scientist");
    }

    @Override
    public void preferEngineer(){
        preference.add("engineer");
    }
    
    
}
