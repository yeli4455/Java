/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;
import model.FieldStats;
import model.SimulatorView;
import model.Person;
import model.Host;
import model.Guest;
import model.Artist;
import model.Scientist;
import model.Engineer;
import model.Field;
import util.ModelConstants;
import java.util.Scanner;
import model.Location;
/**
 *
 * @author yeli4
 */
public class Engine {
    public static void main(String args[]){
//        setConstants();
        
        Field field = generateField();
        FieldStats f = new FieldStats();
        ArrayList<Field> steps = new ArrayList<Field>();
        System.out.println(f.getPopulationDetails(field));
        SimulatorView simulatorView = new SimulatorView(ModelConstants.DEPTH, ModelConstants.WIDTH);
        simulatorView.setColor(Host.class, Color.red);
        simulatorView.setColor(Artist.class,Color.blue);
        simulatorView.setColor(Scientist.class,Color.yellow);
        simulatorView.setColor(Engineer.class,Color.green);
        simulatorView.showStatus(0,field);
        steps.add(field);
        for (int step=1; step<=ModelConstants.SIMULATION_LENGTH; step++){
            ArrayList<Location> locationsWithNewPerson = new ArrayList<Location>();
            for (int i=0; i<ModelConstants.WIDTH; i++){
                for (int j=0; j<ModelConstants.DEPTH; j++){
                    if (steps.get(step-1).getObjectAt(i,j)!=null){
                        Person person = field.getObjectAt(i,j);
                        field = person.act(field);
                       
                  }
                }
            }
            Field fieldClone = field.cloneField();
            steps.add(fieldClone);
        }
        boolean run = true;
        int wantedStep;
        while (run==true){
            System.out.println("Insert the step to beshown;");
            Scanner scan = new Scanner (System.in);
            
            if (scan.hasNextInt()){
                wantedStep=scan.nextInt();
                if (wantedStep>=0 && wantedStep<=ModelConstants.SIMULATION_LENGTH){
                    simulatorView.showStatus(wantedStep, steps.get(wantedStep));
                }
            }
            else if (scan.next().charAt(0)=='s' || scan.next().charAt(0)=='S'){
                run = false;
            }
        }
    }
    
//    static public void setConstants(){
//        System.out.println("Please enter the distance guests can move each step:");
//        Scanner constant = new Scanner (System.in);
//        ModelConstants.setMOVE_DISTANCE(constant.nextInt());
//        System.out.println("Please enter the probability of creating a host:");
//        constant = new Scanner (System.in);
//        ModelConstants.setHOST_CREATION_PROBABILITY(constant.nextDouble());
//        System.out.println("Please enter the probability of creating an artist:");
//        constant = new Scanner (System.in);
//        ModelConstants.setARTIST_CREATION_PROBABILITY(constant.nextDouble());
//        System.out.println("Please enter the probability of creating a scientist:");
//        constant = new Scanner (System.in);
//        ModelConstants.setSCIENTIST_CREATION_PROBABILITY(constant.nextDouble());
//        System.out.println("Please enter the probability of creating an engineer:");
//        constant = new Scanner (System.in);
//        ModelConstants.setENGINEER_CREATION_PROBABILITY(constant.nextDouble());
//        System.out.println("Please enter the width of field:");
//        constant = new Scanner (System.in);
//        ModelConstants.setWIDTH(constant.nextInt());
//        System.out.println("Please enter the depth of field:");
//        constant = new Scanner (System.in);
//        ModelConstants.setDEPTH(constant.nextInt());
//        System.out.println("Please enter the seed for random generator:");
//        constant = new Scanner (System.in);
//        ModelConstants.setSEED(constant.nextInt());
//        System.out.println("Please enter the simulation length:");
//        constant = new Scanner (System.in);
//        ModelConstants.setSIMULATION_LENGTH(constant.nextInt());
//
//}
    static public Field generateField(){
        Field field = new Field(ModelConstants.WIDTH, ModelConstants.DEPTH);
        field.clear();
        Person person;
        for (int i=0; i<ModelConstants.WIDTH; i++){
            for (int j=0; j<ModelConstants.DEPTH; j++){
                person = null;
                Random random = new Random();
                double rand = random.nextDouble();
                if (rand<=ModelConstants.HOST_CREATION_PROBABILITY){
                    person = new Host(i,j);
                }
                else if (rand<=ModelConstants.HOST_CREATION_PROBABILITY+ModelConstants.ARTIST_CREATION_PROBABILITY){
                    person = new Artist(i,j);
                }
                else if (rand<=ModelConstants.HOST_CREATION_PROBABILITY+ModelConstants.ARTIST_CREATION_PROBABILITY+ModelConstants.SCIENTIST_CREATION_PROBABILITY){
                    person = new Scientist(i,j);
                }
                else if (rand<=ModelConstants.HOST_CREATION_PROBABILITY+ModelConstants.ARTIST_CREATION_PROBABILITY+ModelConstants.SCIENTIST_CREATION_PROBABILITY+ModelConstants.ENGINEER_CREATION_PROBABILITY){
                    person = new Engineer(i,j);
                }
                field.place(person,i,j);
            }
        }
        return field;
    }
}
